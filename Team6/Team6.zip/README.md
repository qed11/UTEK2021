# UTEK2021
For UTEK 2021 Programming challenge

1a.py
 The function acc_check takes a filename (str) as a parameter. It will open the json file specified by the filename and generate output file with all the stations that has accessible survices

1b.py

 Function most_accessible takes 2 parameters: a filename that accepts a string that opens a json file specified by the filename, as well as an integer value of k, where k indicates the top k most accessible paths. It will generate output file with a list of the top kth accessible paths. 
 
2.py

To run this code, this file, the input file, and (if already created) the output file should all be in the same directory. Running the program with the input file in the same format specified in an input file called 2.in should yield a result in a corresponding output file 2.out. 

3.py

To run this code, run the command: python 3.py 

4.py

pathFinder is a copy of 2.py - renamed for the sake of an easier import.

To run this code, run the command: python 4.py

